<?php
	include("router.php");
?>