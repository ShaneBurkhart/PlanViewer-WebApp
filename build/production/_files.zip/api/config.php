<?php 
//Misc Config Settings
	$db_name = "vedesi6_plan_viewer";
	$user = "vedesi6_shane";
	$pass = "Java#97Java";
	$server = "localhost";

?>